package com.bluewhale.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {

	@Bean
	public Docket Swaggerconfig() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(PathSelectors
						.ant("/controller/*"))
				.build()
				.apiInfo(new ApiInfo("Movie App by Bluewhale" , "This project Is A Sample Project For Intgrating Swagger With Springboot",
						"1.0", "https://fibyl.com/", new Contact("name", "url", "hello@fibyl.com"), 
						"opensource", "https://fibyl.com/", Collections.emptyList()));
				
	}
	
	
}
